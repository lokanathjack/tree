/*
    Copyright (C) 2012  saminda konkaduwa

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Also add information on how to contact you by electronic and paper mail.
*/

package com.jsptree.bean;

import java.util.List;

/**
 * @author Saminda Konkaduwa , skonkaduwa@gmail.com
 * @version 1.0
 * @since 10/April/2012
 *  
 * This is the heart of tree structure. Entire tree will visualize as a Node. It is called root. It has list of children.  
 */
public class Node {
	// Current node id
	private int nodeId;
	// Current node name
	private String nodeName;
	// Status of node ( checked or not checked )
	private int isSelected;
	// Each node has list of children
	private List<Node> children;	
	// This will hold exceptions if occurred.
	private String errorDescription;
	
	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public List<Node> getChildren() {
		return children;
	}

	public void setChildren(List<Node> children) {
		this.children = children;
	}

	public int getIsSelected() {
		return isSelected;
	}

	public void setIsSelected(int isSelected) {
		this.isSelected = isSelected;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
}


