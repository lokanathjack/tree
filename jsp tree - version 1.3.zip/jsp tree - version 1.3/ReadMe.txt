    Copyright (C) 2012  saminda konkaduwa, skonkaduwa@gmail.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Also add information on how to contact you by electronic and paper mail.


==================================================================================

   @author Saminda Konkaduwa , skonkaduwa@gmail.com
   @version 1.0
   @since 10/April/2012

==================================================================================
				INTRODUCTION

   I am Saminda Konkaduwa from Sri Lanka. I am working for Software Industry since year 2008.
   This is a simple JSP tree viewer with minimum usage of Java Scripts.		
   Nodes are generated using parent child relationships. 
   Each node may have list of children nodes.

   I would like to listen you if you would like to improve this project in order to help community.
   Inbox me skonkaduwa at gmail.com
   Bye
==================================================================================


				How To deploy


Prerequisites.
-------------
1. You should know what is Java web application and How to deploy Java Web application project in your web server.
2. You should know how to install latest Java, MySQL Server and Apache Tomcat Server in your operating system


To install, build and run the given WAR file
--------------------------------------------
1. Install latest Java version, MySQL server version, Apache Tomcat Server version.
2. Download the source code from http://sourceforge.net/projects/jsptree-simple/
3. Run the SQL statements given by SQLFile.txt on your MySQL server.
4. Open the given simple-jsp-tree.war file located at WebContent folder using zip / rar utilities. ( Becaues you can edit the war file content after open it by zip )
5. Find the config.properties located at simple-jsp-tree.war/WEB-INF/classes/com/jsptree/tags/config.properties.
6. Change config.properties according to your MySQL database server connectivity. 
7. Save the changes on config.properties and exit from zip / rar utilities. 
8. Then deploy simple-jsp-tree.war in your Apache Tomcat Server. 
9. Access the simple JSP tree from http://localhost:8080/simple-jsp-tree

For Oracle JDBC Connection, Please override config.properties entries as with your Oracle database connection as follows.

jdbc.driver=oracle.jdbc.xa.client.OracleXADataSource
jdbc.connection.url=jdbc:oracle:thin:@localhost:1521:xe		( NOTE : xe is my database name. Change it to your Oracle database name )
jdbc.username=oracle_user									( NOTE : oracle_user is my Oracle user name. Change it to your oracle user name )
jdbc.password=oracle@123									( NOTE : oracle@123 is my Oracle password. Change it to your oracle password )


						
						
						
To build and run from source files
----------------------------------

1. Install latest Java version, MySQL server version, Apache Tomcat Server version and your favorite Java Development IDE. ( Ex- Eclipse, Netbean)
2. Download the source code from http://sourceforge.net/projects/jsptree-simple/
3. Open your favorite Java Development IDE. ( Ex- Eclipse, Netbean)
4. Create simple JSP project.
5. Go to the downloaded source code and extract in to separate folder.
6. Copy the content of src folder to java source location of your JSP project. 
7. Go to the downloaded source code again and copy the content of WebContent folder to web content of your JSP project. 
8. Run the project using your favorite web server.



For Oracle JDBC Connection, Please override config.properties entries as with your Oracle database connection  as follows.

jdbc.driver=oracle.jdbc.xa.client.OracleXADataSource
jdbc.connection.url=jdbc:oracle:thin:@localhost:1521:xe		( NOTE : xe is my database name. Change it to your Oracle database name )
jdbc.username=oracle_user									( NOTE : oracle_user is my Oracle user name. Change it to your oracle user name )
jdbc.password=oracle@123									( NOTE : oracle@123 is my Oracle password. Change it to your oracle password )


For example, Change     jdbc.driver=com.mysql.jdbc.Driver    in to    jdbc.driver=oracle.jdbc.xa.client.OracleXADataSource

==================================================================================

	   			END

==================================================================================



